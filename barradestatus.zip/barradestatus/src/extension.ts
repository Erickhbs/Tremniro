import * as vscode from 'vscode'

let statusBarItem: vscode.StatusBarItem

export function activate(context: vscode.ExtensionContext) {
	statusBarItem = vscode.window.createStatusBarItem(
		vscode.StatusBarAlignment.Left,
		10000
	)
	
	context.subscriptions.push(statusBarItem)
	
	updateStatusBar(context)
}

function updateStatusBar(context: vscode.ExtensionContext){
	statusBarItem.text = 'Erick Henrique Barros da Silva'
	statusBarItem.tooltip = 'Hello World'
	statusBarItem.show()
}

export function deactivate() {}